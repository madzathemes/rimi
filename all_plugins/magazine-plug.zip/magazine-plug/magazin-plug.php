<?php
/*
Plugin Name: Magazine Plug
Plugin URI: https://themeforest.net
Description: Magazin Plugin
Author: Madars Bitenieks
Version: 4.3.9
Author URI: https://themeforest.net
*/
include_once ('magazin-extras.php');
